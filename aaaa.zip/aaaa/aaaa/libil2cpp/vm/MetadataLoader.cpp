#include "il2cpp-config.h"
#include "MetadataLoader.h"
#include "os/File.h"
#include "os/Mutex.h"
#include "utils/MemoryMappedFile.h"
#include "utils/PathUtils.h"
#include "utils/Runtime.h"
#include "utils/Logging.h"

void* il2cpp::vm::MetadataLoader::LoadMetadataFile(const char* fileName)


{

    utils::Logging::Write(" MetadataLoader version 2 17:44 ");

    std::string resourcesDirectory = utils::PathUtils::Combine(utils::Runtime::GetDataDir(), utils::StringView<char>("Metadata"));

    std::string resourceFilePath = utils::PathUtils::Combine(resourcesDirectory, utils::StringView<char>(fileName, strlen(fileName)));

    int error = 0;
    utils::Logging::Write("LoadMetadataFile %d",  1);
    os::FileHandle* handle = os::File::Open(resourceFilePath, kFileModeOpen, kFileAccessRead, kFileShareRead, kFileOptionsNone, &error);
    utils::Logging::Write("LoadMetadataFile %d",  2);
    if (error != 0)
    {
        utils::Logging::Write("ERROR: Could not open %s", resourceFilePath.c_str());
        return NULL;
    }
    utils::Logging::Write("LoadMetadataFile %d",  3);


// #if METADATA_OFFSET
    // os::File::Seek(handle, 4, 0, &error);
// #endif 

    void* fileBuffer = utils::MemoryMappedFile::Map(handle, 0, 4);
    utils::Logging::Write("LoadMetadataFile error %d",  error);

    os::File::Close(handle, &error);
    

    if (error != 0)
    {
        utils::MemoryMappedFile::Unmap(fileBuffer);
        fileBuffer = NULL;
        return NULL;
    }
    

    return fileBuffer;
}
